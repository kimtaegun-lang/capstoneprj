package com.example.mainproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.List;

public class menu_information_activity extends AppCompatActivity {
    TextView menu_information_name, menu_information_material,menu_information_do;
    RatingBar menu_rating;
    Button menu_rating_btn;
    int[] imgs = {R.drawable.home_image1};

private UserDao mUserDao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_information_activity);

        UserDatabase database= Room.databaseBuilder(getApplicationContext(),UserDatabase.class,"menuinfo")
                .fallbackToDestructiveMigration() // 스키마 버전 변경 가능
                .allowMainThreadQueries() // main thread에서 db에 입출력을 가능하게함.
                .build();

        mUserDao=database.userDao(); // 인터페이스 객체 할당

        User user_array[]=new User[7];
        user_array[0].setMenuName("참치마요덮밥");
        user_array[0].setMenuMaterial("간장 1큰술, 마요네즈 1큰술, 참치...");
        user_array[0].setMenuDo("1. 간장과 마요네즈를 섞는다, 2. 참치와 소스를 섞는다,");

        user_array[1].setMenuName("스팸주먹밥");
        user_array[1].setMenuMaterial("간장 1큰술, 마요네즈 1큰술, 참치...");
        user_array[1].setMenuDo("1. 간장과 마요네즈를 섞는다, 2. 참치와 소스를 섞는다,");

        user_array[2].setMenuName("김치볶음밥");
        user_array[2].setMenuMaterial("간장 1큰술, 마요네즈 1큰술, 참치...");
        user_array[2].setMenuDo("1. 간장과 마요네즈를 섞는다, 2. 참치와 소스를 섞는다,");

        user_array[3].setMenuName("계란볶음밥");
        user_array[3].setMenuMaterial("간장 1큰술, 마요네즈 1큰술, 참치...");
        user_array[3].setMenuDo("1. 간장과 마요네즈를 섞는다, 2. 참치와 소스를 섞는다,");

        user_array[4].setMenuName("김밥");
        user_array[4].setMenuMaterial("간장 1큰술, 마요네즈 1큰술, 참치...");
        user_array[4].setMenuDo("1. 간장과 마요네즈를 섞는다, 2. 참치와 소스를 섞는다,");

        user_array[5].setMenuName("오므라이스");
        user_array[5].setMenuMaterial("간장 1큰술, 마요네즈 1큰술, 참치...");
        user_array[5].setMenuDo("1. 간장과 마요네즈를 섞는다, 2. 참치와 소스를 섞는다,");

        user_array[6].setMenuName("간장계란밥");
        user_array[6].setMenuMaterial("간장 1큰술, 마요네즈 1큰술, 참치...");
        user_array[6].setMenuDo("1. 간장과 마요네즈를 섞는다, 2. 참치와 소스를 섞는다,");

        for(int i=0;i< user_array.length;i++) {
            mUserDao.setInsertUser(user_array[i]);
        }


        menu_information_name=(TextView) findViewById(R.id.menu_information_name);
        menu_information_material=(TextView) findViewById(R.id.menu_information_material);
        menu_information_do=(TextView) findViewById(R.id.menu_information_do);


        List<User> userList=mUserDao.getUserAll();


        int getInt=getIntent().getIntExtra("number",1);
        menu_information_name.setText(userList.get(getInt).getMenuName());
        menu_information_material.setText(userList.get(getInt).getMenuMaterial());
        menu_information_do.setText(userList.get(getInt).getMenuDo());


        menu_rating_btn = (Button) findViewById(R.id.menu_information_btn);
        menu_rating = (RatingBar) findViewById(R.id.menu_rating);
        menu_rating_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float rating_value1 = menu_rating.getRating();
            }
        });

    }


}

