package com.example.mainproject;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class User {
    @PrimaryKey(autoGenerate = true)
    private int id=0; // 사용자에대한 고유 아이디 값
    private String MenuName;
    private String MenuMaterial;
    private String MenuDo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMenuName() {
        return MenuName;
    }

    public void setMenuName(String menuName) {
        MenuName = menuName;
    }

    public String getMenuMaterial() {
        return MenuMaterial;
    }

    public void setMenuMaterial(String menuMaterial) {
        MenuMaterial = menuMaterial;
    }

    public String getMenuDo() {
        return MenuDo;
    }

    public void setMenuDo(String menuDo) {
        MenuDo = menuDo;
    }
}
