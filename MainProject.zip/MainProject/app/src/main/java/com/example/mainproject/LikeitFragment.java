package com.example.mainproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

public class LikeitFragment extends Fragment {
TextView likeit_tv[]=new TextView[70]; // 각 요리들의 이름을 받아오는 변수
SearchView likeit_searchview; // 서치뷰 객체를 받아오는 변수
String getQuery; // 사용자의 검색 텍스트를 받아오는 변수
 LinearLayout likeit_linear[]=new LinearLayout[70]; // 리니어 레이아웃의 disvillity 속성을 가져오기 위한 리니어 배열

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View likeit = inflater.inflate(R.layout.fragment_likeit, container, false);

        for(int i=0;i<likeit_tv.length;i++)
        {
            // 찜 목록 여부를 알아와 visible 시키는 부분
        }

        for(int i=0;i<likeit_tv.length;i++)
        {
            int linearId = getResources().getIdentifier("likeit_linear" + (i+1), "id", this.getActivity().getPackageName());
            likeit_linear[i] = (LinearLayout) likeit.findViewById(linearId); // 리니어 레이아웃 배열에 각각 아이디를 부여함.

            if(likeit_linear[i].getVisibility()==View.VISIBLE) { // 리니어 레이아웃 배열이 visible 상태일 경우, 해당 텍스트 뷰에 아이디 부여
                int tvId = getResources().getIdentifier("likeit_tv" + (i+1), "id", this.getActivity().getPackageName());
                likeit_tv[i] = (TextView) likeit.findViewById(tvId);
            }
        }
        likeit_searchview=(SearchView)likeit.findViewById(R.id.likeit_searchview);

        return likeit;
    }
}