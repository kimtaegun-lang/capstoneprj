package com.example.mainproject;

import android.content.Intent;
import android.graphics.ImageDecoder;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

public class HomeFragment extends Fragment {
 ImageView home_img[]=new ImageView[8];

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) { // 메인화면에서 클릭시 음식 종류 액티비티로 이동 ex) 밥류,면류...

        View home = inflater.inflate(R.layout.fragment_home, container, false);
        for(int i=1;i<8;i++) {
            int imgId = getResources().getIdentifier("Home_img" + i, "id", this.getActivity().getPackageName());
            home_img[i] = (ImageView) home.findViewById(imgId);
        }
            home_img[1].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), menu_activity1.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
                }
            });

        return home;

    }
}
