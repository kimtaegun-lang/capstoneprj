package com.example.mainproject;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class all_menu_activity extends AppCompatActivity {
    String home_query; // home fragment에서 부터 사용자 검색 내용을 받거나, all_menu_activity에서 serachview의 검색 결과를 받는 변수
    TextView all_menu_tv[] = new TextView[70]; // all_ment 액티비티의 요리 이름을 담아오는 변수
    LinearLayout all_menu_linear[] = new LinearLayout[70]; // akk_menu 액티비티의 요리 메뉴 탭 공간을 담아오는 변수
    SearchView all_menu_searchview;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.all_menu_activity);
        home_query = getIntent().getStringExtra("search_key"); // intent로 부터 home fragment로부터 검색 내용을 받는 구문

        all_menu_searchview = (SearchView) findViewById(R.id.all_menu_searchview);
        for (int i = 0; i < all_menu_tv.length; i++) // all_menu_activity의 리니어 레이아웃, 텍스트 뷰 아이디 지정 구문
        {
            int all_menu_linearId = getResources().getIdentifier("all_menu_linear" + (i + 1), "id", this.getPackageName());
            all_menu_linear[i] = (LinearLayout) findViewById(all_menu_linearId); // 리니어 레이아웃 배열에 각각 아이디를 부여함.

            int all_menu_tvId = getResources().getIdentifier("all_menu_tv" + (i + 1), "id", this.getPackageName());
            all_menu_tv[i] = (TextView) findViewById(all_menu_tvId);
        }
        for (int i = 0; i < all_menu_tv.length; i++) { // 처음 all_menu_activity에 왔을때 home fragment의 검색값을 통해 메뉴를 보이게하는 구문
            if (all_menu_tv[i].getText().toString().contains(home_query)) {
                all_menu_linear[i].setVisibility(View.VISIBLE);
            } else
                all_menu_linear[i].setVisibility(View.GONE);
        }

        all_menu_searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() { // 이후 all_menu_activity에서 검색을 수행하는 구문
            @Override
            public boolean onQueryTextSubmit(String query) { // 검색을 했을 경우,
                home_query= all_menu_searchview.getQuery().toString();
                for (int i = 0; i < all_menu_tv.length; i++) {
                if (all_menu_tv[i].getText().toString().contains(home_query)) {
                    all_menu_linear[i].setVisibility(View.VISIBLE);
                } else
                    all_menu_linear[i].setVisibility(View.GONE);
                }
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) { // 검색에 텍스트가 변했을 경우

                return false;
            }
        });
    }

    public static class menu_activity2 {
    }
}




