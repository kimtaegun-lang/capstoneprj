package com.example.mainproject;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class menu_activity3 extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity3);

    }
}