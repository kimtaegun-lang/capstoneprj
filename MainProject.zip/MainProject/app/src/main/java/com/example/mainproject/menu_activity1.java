package com.example.mainproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class menu_activity1 extends AppCompatActivity {
LinearLayout menu_activity1_linear[]=new LinearLayout[10];

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity1);

        for (int i = 0; i < menu_activity1_linear.length; i++)
        {
            int menu_activity1_linearId = getResources().getIdentifier("menu_activity1_linear" + (i + 1), "id", this.getPackageName());
            menu_activity1_linear[i] = (LinearLayout) findViewById(menu_activity1_linearId); // 리니어 레이아웃 배열에 각각 아이디를 부여함.

        }
        Intent intent=new Intent(getApplicationContext(),menu_information_activity.class);
       menu_activity1_linear[0].setOnClickListener(new View.OnClickListener() {
          @Override
            public void onClick(View v) {
             intent.putExtra("number",1);
             startActivity(intent);
           }
      });


        menu_activity1_linear[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("number",2);
                startActivity(intent);
            }
        });

        menu_activity1_linear[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("number",3);
                startActivity(intent);
            }
        });

        menu_activity1_linear[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("number",4);
                startActivity(intent);
            }
        });

        menu_activity1_linear[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("number",5);
                startActivity(intent);
            }
        });

        menu_activity1_linear[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("number",6);
                startActivity(intent);
            }
        });

        menu_activity1_linear[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("number",8);
                startActivity(intent);
            }
        });

        menu_activity1_linear[8].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("number",9);
                startActivity(intent);
            }
        });

        menu_activity1_linear[9].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("number",10);
                startActivity(intent);
            }
        });

    }
}
