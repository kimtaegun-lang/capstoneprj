package com.example.mainproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class menu_activity1 extends AppCompatActivity {

    LinearLayout menu_bap_linear[]=new LinearLayout[11];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity1);
        for(int i=1;i<11;i++) {
            int menu_bap_linear_array = getResources().getIdentifier("menu_bap_linear" + i, "id",getPackageName());
            menu_bap_linear[i] = (LinearLayout) findViewById(menu_bap_linear_array);
        }

        menu_bap_linear[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), menu_information_activity1.class);
                startActivity(intent);
            }
        });
    }
}
